﻿using System.Collections.Generic;

public class RaceTower
{
    private void SetTrackInfo(int lapsNumber, int trackLength)
    {
        //TODO: Add some logic here …
    }

    private void RegisterDriver(List<string> commandArgs)
    {
        //TODO: Add some logic here …
    }

    private void DriverBoxes(List<string> commandArgs)
    {
        //TODO: Add some logic here …
    }

    private string CompleteLaps(List<string> commandArgs)
    {
        return "";
    }

    private string GetLeaderboard()
    {
        return "";
    }

    private void ChangeWeather(List<string> commandArgs)
    {
        //TODO: Add some logic here …
    }
}