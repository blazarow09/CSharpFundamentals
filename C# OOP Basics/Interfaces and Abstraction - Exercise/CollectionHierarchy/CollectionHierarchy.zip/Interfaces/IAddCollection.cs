﻿public interface IAddCollection
{
    int Add(string item);
}