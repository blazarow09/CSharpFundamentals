﻿
    public interface IAddRemoveCollection
    {
    string Remove();
    }

