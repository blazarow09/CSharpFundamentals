﻿public interface IMylist
{
    int Used { get; }
}